1、Chassis_Power_Limit（）里面的speed_zoom =0 屏蔽底盘    
2、发射拨盘需要修改反转判断时长
3、Pitch和yaw轴独立控制
4、Higher_class里面的底盘补偿函数屏蔽掉